
## ------------------------------------------------------------------------
library(isomiRs)
data(isomiRex)


## ----fig.width=7, fig.height=6-------------------------------------------
#check plot iso
obj<-plotIso(obj,type="t5")


## ----dev='jpeg'----------------------------------------------------------
dds<-deIso(obj,formula=~condition,ref=TRUE,iso5=T)
#plotMA
library(DESeq2)
plotMA(dds)


## ----eval=FALSE----------------------------------------------------------
## obj<-makeCounts(obj,ref=T)
## obj<-normIso(obj)
## pls.obj<-isoPLSDA(obj,"condition")
## isoPLSDAplot(pls.obj$component,obj@design[,"condition"])


## ----eval=FALSE----------------------------------------------------------
## pls.obj<-isoPLSDA(obj,"condition",refinment=TRUE)


