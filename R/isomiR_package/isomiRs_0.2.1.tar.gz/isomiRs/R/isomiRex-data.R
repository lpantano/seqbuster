#' @name isomiRex
#' @title isomirDataSeq
#' @description This data set is the object return by \code{loadIso}
#' @docType data
#' @usage isomiRex
#' @format a \code{isomirDataSeq} instance, 1 row per CpG island.
#' @author Lorena Pantano, 2014-04-08
NULL