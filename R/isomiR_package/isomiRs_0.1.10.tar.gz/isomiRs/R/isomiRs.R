library(data.table)
library(ggplot2)

summary<-function(x){
  UseMethod("summary")
}

plotIso<-function(x){
  UseMethod("plotIso")
}

summary.Isomirs<-function(x){
  #whatever to do with my object (generic information)
}

plotIso.Isomirs<-function(x,type="t5"){
  #whatever to do with my object (generic information)
  code<-4
  ratio<-1/6
  des<-x[["design"]]
  table<-data.frame()
  for (sample in row.names(des)){
    temp<-data.table(x[[sample]][[code]])
    temp<-temp[,list(freq=sum(freq)),by="size"]  
    total<-sum(temp$freq)
    temp$freqn<-log2(temp$freq/(ratio*total))
    table<-rbind(table,data.frame(size=temp$size,score=temp$freqn,
                                  sample=sample,
                                  group=des[sample,"condition"]))
  }
  p <- ggplot(table, aes(x=factor(size), y=score,fill=group))+
    geom_violin()+
    geom_jitter(position=position_jitter(width=0.2),
                aes(factor(size),score,colour=sample)) +
    scale_fill_brewer(palette="Set1",guide="none")+
    scale_colour_brewer(palette="Set1",guide="none")+
    theme_bw(base_size = 14, base_family = "") +
    theme(strip.background=element_rect(fill="slategray3"))+
    labs(list(title=paste(type,"distribution"),y="score",
              x="position respect to the reference"))
    print(p)  
}


loadIso<-function(files,design,cov=10){
  listObj<-vector("list")
  idx<-0
  for (f in files){
    idx<-idx+1
    d<-read.table(f,header=T)
    d[,2]<-as.numeric(d[,2])
    d<-put.header(d)
    d<-filter.by.cov(d,cov)
    #Run function to describe isomirs
    out<-list(counts=d,design=design[idx,],summary=0,te5sum=isomir.position(d,8),t3sum=isomir.position(d,9),subsum=subs.position(d,6),addsum=isomir.position(d,7))
    #class(out)<-"Isomirs"
    listObj[[row.names(design)[idx]]]<-out
  }
  listObj[["design"]]<-design
  class(listObj)<-"Isomirs"
  return(listObj)
}
  
do.mir.table<-function(files,names,cov=10,ref=F,iso5=F,iso3=F,add=F,mism=F,seed=F){
  table.merge<-data.frame()
  for (f in files){
    
    d<-read.table(f,header=T)
    d[,2]<-as.numeric(d[,2])
    d<-put.header(d)
    d<-filter.by.cov(d,cov)
    d<-collapse.mirs(d,ref=ref,iso5=iso5,iso3=iso3,add=add,mism=mism,seed=seed)
    names(d)[ncol(d)]<-names[files==f]
    
    if( nrow(table.merge)==0){
      table.merge<-d
    }else{
      table.merge<-merge(table.merge,d,by=1,all=T)
    }
    
  }
  return(table.merge)
}

collapse.mirs<-function(table,ref=F,iso5=F,iso3=F,add=F,mism=F,seed=F){
  label<-table$mir
  if (ref==T){
    ref.val<-do.call(paste,table[,6:9])
    ref.val[grep("[ATGC]",ref.val,invert=T)]<-"ref"
    ref.val[grep("[ATGC]",ref.val)]<-"iso"
    label<-paste(label,ref.val,sep=".")
  }
  if (iso5==T){
    label<-paste(label,table[,8],sep=".")
  }
  if (seed==T){
    seed.val<-as.character(table[,6])
    seed.val[grep("^[2-8][ATGC]",seed.val,invert=T)]<-"no"
    label<-paste(label,seed.val,sep=".")
  }
  if (iso3==T){
    label<-paste(label,table[,9],sep=".")
  }
  if (add==T){
    label<-paste(label,table[,7],sep=".")
  }
  if (mism==T){
    label<-paste(label,table[,6],sep=".")
  }
  
  table$id<-label
  table.out<-data.table(table)
  
  table.out<-as.data.frame(table.out[,list(total=sum(freq)),by=c('id')])
  table.out[is.na(table.out)]<-0
  return(table.out)
}

put.header<-function(table){
  
  if (names(table)[3]!="mir"){
    names(table)[c(2,3,6,7,8,9,12,13)]<-c("freq","mir","mism","add","t3","t5","DB","ambiguity")
  }
  return(table)
}

filter.by.cov<-function(table,limit=10){
  
  table.out<-data.table(table)
  table.out<-table.out[table.out$DB=="miRNA",]
  table.out<-as.data.frame(table.out[,list(total=sum(freq)),by=c('mir')])
  table<-merge(table[,c(3,1:2,4:ncol(table))],table.out,by=1)
  table$score<-table$freq/table$total*100
  table<-table[table$score>=limit,]
  return (table)
  
}

isomir.general.type<-function(table,colid){
  temp<-table
  temp$idfeat<-paste(table[,colid],table$mir)
  temp<-temp[order(temp$idfeat),]
  temp<-temp[!duplicated(temp$idfeat),]
  temp<-as.data.frame(summary(temp$mir))
  feat.dist<-cut(as.numeric(temp[,1]),breaks=c(-1,0.5,1.5,2.5,Inf),labels=c("0","1","2",">3"))
  return (as.data.frame(summary(feat.dist)))  
}

make.figure.general<-function(table){
  
  mism<-isomir.general.type(table,6)
  add<-isomir.general.type(table,7)
  t3<-isomir.general.type(table,8)
  t5<-isomir.general.type(table,9)
  dat<-data.frame(rbind(t5,t3,add,mism))
  names(dat)<-"count"
  dat$type<-c(rep("5 trimming",nrow(t5)),rep("3 trimming",nrow(t3)),rep("nt addition",nrow(add)),rep("nt subst",nrow(mism)))
  dat$iso<-c(row.names(t5),row.names(t3),row.names(add),row.names(mism))
  dat$iso<-factor(dat$iso,levels=c(0,1,2,">3"))
  p<-ggplot(dat,aes(x = factor(type), y = count, fill=iso)) +
    geom_bar(stat = "identity") +
    scale_fill_brewer(palette="Set1") +
    theme_bw(base_size = 12, base_family = "") +
    labs(list(x="",y="# of miRNAs",fill="# of isomirs"))
  print(p)
}

isomir.position<-function(table,colid){
  temp<-table
  temp[,colid]<-as.character(temp[,colid])
  pos<-as.data.frame(t(as.data.frame((strsplit(temp[,colid],"-",fixed=2)))))
  row.names(pos)<-1:nrow(pos)
  pos$mir<-temp$mir
  pos$freq<-temp$freq
  pos<-pos[pos[,1]!=0,]
  pos$size<-apply(pos,1,function(x){
    p<-length(unlist(strsplit(x[2],"")))
    if(x[1]=="d"){
      p<-p*-1
    }
    return(p)
  })
  pos$idfeat<-paste(pos$size,pos$mir)
  pos<-pos[order(pos$idfeat,abs(pos$size)),]
  #pos<-pos[!duplicated(pos$idfeat),]
  #pos<-as.data.frame(summary(pos$mir))
  return (pos[,c(3,4,5)])  
}
subs.position<-function(table,colid){
  temp<-table
  temp[,colid]<-as.character(temp[,colid])
  nt<-sub("[0-9]+","",temp[,colid])  
  pos<-sub("[ATGC]{2}","",temp[,colid])
  pos<-data.frame(nt=as.character(nt),pos=pos,mir=temp$mir,freq=temp$freq)
  pos$nt<-as.character(pos$nt)
  pos<-pos[pos[,1]!="",]
  nt.2<-as.data.frame(t(as.data.frame((strsplit(pos$nt,"",fixed=2)))))
  names(nt.2)<-c("current","reference")
  names(nt.2$current)<-""
  names(nt.2$reference)<-""
  pos<-cbind(pos,nt.2)
  return (pos[,c(3,4,2,5,6)])  
  
}

filter.table<-function(table,cov=10){
  
  table[,2]<-as.numeric(table[,2])
  table<-put.header(table)
  table<-filter.by.cov(table,cov)
  return(table)
  
}